create view om_history_view as select distinct `t`.`ID`            AS `ID`,
                                               `t`.`OPERATIONTYPE` AS `OPERATIONTYPE`,
                                               `t`.`ENTITY`        AS `ENTITY`,
                                               `t`.`ENTITYID`      AS `ENTITYID`,
                                               `t`.`DESCRIPTION`   AS `DESCRIPTION`,
                                               `t`.`CREATETIME`    AS `CREATETIME`,
                                               `t`.`OPERATOR`      AS `OPERATOR`,
                                               `u`.`USERID`        AS `entitycode`,
                                               `u`.`EMPNAME`       AS `entityname`,
                                               `u2`.`USERID`       AS `operatoruid`,
                                               `u2`.`EMPNAME`      AS `operatorname`,
                                               'OMUser'            AS `entitytype`,
                                               `u`.`ORGID`         AS `orgid`
                               from ((`cms`.`om_history` `t` join `cms`.`om_user` `u`) join `cms`.`om_user` `u2`)
                               where ((`t`.`ENTITY` = 'com.unionpay.portal.uum.entity.om.OMUser') and
                                      (`t`.`ENTITYID` = `u`.`EMPID`) and (`t`.`OPERATOR` = `u2`.`EMPID`))
                               union all select distinct `t`.`ID`            AS `ID`,
                                                         `t`.`OPERATIONTYPE` AS `OPERATIONTYPE`,
                                                         `t`.`ENTITY`        AS `ENTITY`,
                                                         `t`.`ENTITYID`      AS `ENTITYID`,
                                                         `t`.`DESCRIPTION`   AS `DESCRIPTION`,
                                                         `t`.`CREATETIME`    AS `CREATETIME`,
                                                         `t`.`OPERATOR`      AS `OPERATOR`,
                                                         `o`.`ORGCODE`       AS `entitycode`,
                                                         `o`.`ORGNAME`       AS `entityname`,
                                                         `u2`.`USERID`       AS `operatoruid`,
                                                         `u2`.`EMPNAME`      AS `operatorname`,
                                                         'OMOrganization'    AS `entitytype`,
                                                         `o`.`ORGID`         AS `orgid`
                                         from ((`cms`.`om_history` `t` join `cms`.`om_organization` `o`) join `cms`.`om_user` `u2`)
                                         where ((`t`.`ENTITY` = 'com.unionpay.portal.uum.entity.om.OMOrganization') and
                                                (`t`.`ENTITYID` = `o`.`ORGID`) and (`t`.`OPERATOR` = `u2`.`EMPID`));

