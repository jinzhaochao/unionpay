create view dept_peop_view as select distinct `t`.`ID`       AS `id`,
                                              `t`.`MEET_ID`  AS `meet_id`,
                                              `t`.`USERID`   AS `userid`,
                                              `t`.`USERNAME` AS `username`,
                                              `g`.`ORGID`    AS `deptid`,
                                              `g`.`ORGNAME`  AS `deptname`,
                                              `g`.`ORGSEQ`   AS `orgseq`,
                                              `t`.`REMARK`   AS `remark`,
                                              `t`.`TYPE`     AS `type`,
                                              `t`.`STATUS`   AS `status`,
                                              `t`.`OKTIME`   AS `oktime`,
                                              '1'            AS `meettype`,
                                              `u`.`EMPID`    AS `empid`,
                                              `u`.`EMPNAME`  AS `empname`,
                                              `u`.`SORTNO`   AS `sortno`
                              from ((`cms`.`t_meet_people` `t` join `cms`.`om_user` `u`) join `cms`.`om_organization` `g`)
                              where ((`t`.`USERID` = `u`.`EMPID`) and (`u`.`ORGID` = `g`.`ORGID`))
                              union all select distinct `t`.`ID`      AS `id`,
                                                        `t`.`MEET_ID` AS `meet_id`,
                                                        0             AS `userid`,
                                                        ''            AS `username`,
                                                        `g`.`ORGID`   AS `deptid`,
                                                        `g`.`ORGNAME` AS `deptname`,
                                                        `g`.`ORGSEQ`  AS `orgseq`,
                                                        `t`.`REMARK`  AS `remark`,
                                                        `t`.`TYPE`    AS `type`,
                                                        `t`.`STATUS`  AS `status`,
                                                        `t`.`OKTIME`  AS `oktime`,
                                                        '2'           AS `meettype`,
                                                        `e`.`EMPID`   AS `empid`,
                                                        `e`.`EMPNAME` AS `empname`,
                                                        `e`.`SORTNO`  AS `sortno`
                                        from ((((`cms`.`t_meet_dept` `t` join `cms`.`om_organization` `g`) join `cms`.`om_user` `e`) join `cms`.`om_organization` `g1`) join `cms`.`om_emporg` `om`)
                                        where ((`t`.`DEPTID` = `om`.`ORGID`) and (`om`.`ORGID` = `g`.`ORGID`) and
                                               (`om`.`EMPID` = `e`.`EMPID`) and
                                               (`g1`.`ORGSEQ` like concat(`g`.`ORGSEQ`, '%')) and (not(exists(select 1
                                                                                                              from `cms`.`t_meet_people` `p`
                                                                                                              where ((`t`.`MEET_ID` = `p`.`MEET_ID`) and
                                                                                                                     (`e`.`EMPID` = `p`.`USERID`) and
                                                                                                                     (`p`.`TYPE` = `t`.`TYPE`))))))
                              union all select distinct `t`.`ID`       AS `id`,
                                                        `t`.`MEET_ID`  AS `meet_id`,
                                                        `t`.`USERID`   AS `userid`,
                                                        `t`.`USERNAME` AS `username`,
                                                        `g`.`ORGID`    AS `deptid`,
                                                        `g`.`ORGNAME`  AS `deptname`,
                                                        `g`.`ORGSEQ`   AS `orgseq`,
                                                        `t`.`REMARK`   AS `remark`,
                                                        `t`.`TYPE`     AS `type`,
                                                        `t`.`STATUS`   AS `status`,
                                                        `t`.`OKTIME`   AS `oktime`,
                                                        '1'            AS `meettype`,
                                                        `u`.`EMPID`    AS `empid`,
                                                        `u`.`EMPNAME`  AS `empname`,
                                                        `u`.`SORTNO`   AS `sortno`
                                        from ((`cms`.`t_meet_notify_people` `t` join `cms`.`om_user` `u`) join `cms`.`om_organization` `g`)
                                        where ((`t`.`USERID` = `u`.`EMPID`) and (`u`.`ORGID` = `g`.`ORGID`))
                              union all select distinct `t`.`ID`       AS `id`,
                                                        `t`.`MEET_ID`  AS `meet_id`,
                                                        `t`.`USERID`   AS `userid`,
                                                        `t`.`USERNAME` AS `username`,
                                                        `g`.`ORGID`    AS `deptid`,
                                                        `g`.`ORGNAME`  AS `deptname`,
                                                        `g`.`ORGSEQ`   AS `orgseq`,
                                                        `t`.`REMARK`   AS `remark`,
                                                        `t`.`TYPE`     AS `type`,
                                                        `t`.`STATUS`   AS `status`,
                                                        `t`.`OKTIME`   AS `oktime`,
                                                        '1'            AS `meettype`,
                                                        `u`.`EMPID`    AS `empid`,
                                                        `u`.`EMPNAME`  AS `empname`,
                                                        `u`.`SORTNO`   AS `sortno`
                                        from ((`cms`.`t_meet_cc_people` `t` join `cms`.`om_user` `u`) join `cms`.`om_organization` `g`)
                                        where ((`t`.`USERID` = `u`.`EMPID`) and (`u`.`ORGID` = `g`.`ORGID`))
                              union all select distinct `t`.`ID`      AS `id`,
                                                        `t`.`MEET_ID` AS `meet_id`,
                                                        0             AS `userid`,
                                                        ''            AS `username`,
                                                        `g`.`ORGID`   AS `deptid`,
                                                        `g`.`ORGNAME` AS `deptname`,
                                                        `g`.`ORGSEQ`  AS `orgseq`,
                                                        `t`.`REMARK`  AS `remark`,
                                                        `t`.`TYPE`    AS `type`,
                                                        `t`.`STATUS`  AS `status`,
                                                        `t`.`OKTIME`  AS `oktime`,
                                                        '2'           AS `meettype`,
                                                        `e`.`EMPID`   AS `empid`,
                                                        `e`.`EMPNAME` AS `empname`,
                                                        `e`.`SORTNO`  AS `sortno`
                                        from ((((`cms`.`t_meet_cc_dept` `t` join `cms`.`om_organization` `g`) join `cms`.`om_user` `e`) join `cms`.`om_organization` `g1`) join `cms`.`om_emporg` `om`)
                                        where ((`t`.`DEPTID` = `om`.`ORGID`) and (`om`.`ORGID` = `g`.`ORGID`) and
                                               (`om`.`EMPID` = `e`.`EMPID`) and
                                               (`g1`.`ORGSEQ` like concat(`g`.`ORGSEQ`, '%')) and (not(exists(select 1
                                                                                                              from `cms`.`t_meet_cc_people` `p`
                                                                                                              where ((`t`.`MEET_ID` = `p`.`MEET_ID`) and
                                                                                                                     (`e`.`EMPID` = `p`.`USERID`) and
                                                                                                                     (`p`.`TYPE` = `t`.`TYPE`))))));

