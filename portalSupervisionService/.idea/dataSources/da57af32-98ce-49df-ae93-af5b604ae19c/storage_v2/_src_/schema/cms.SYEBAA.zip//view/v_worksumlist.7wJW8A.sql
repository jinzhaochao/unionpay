create view v_worksumlist as select `cs`.`ID`                   AS `id`,
                                    `cs`.`USERID`               AS `USERID`,
                                    `ou`.`EMPNAME`              AS `empname`,
                                    `cs`.`STARTTIME`            AS `STARTTIME`,
                                    `cs`.`ENDTIME`              AS `Endtime`,
                                    ifnull(`cs`.`SUMMARY`, ' ') AS `summary`,
                                    `cs`.`SUMTITLE`             AS `SUMTITLE`,
                                    'U'                         AS `DT`,
                                    `pdou`.`EMPID`              AS `dtid`
                             from ((((`cms`.`c_summary` `cs` join `cms`.`purview` `pv`) join `cms`.`purview_dept` `pd`) join `cms`.`om_user` `ou`) join `cms`.`om_user` `pdou`)
                             where ((`cs`.`PID` = `pv`.`ID`) and (`pv`.`ID` = `pd`.`PID`) and
                                    (`cs`.`USERID` = `ou`.`EMPID`) and (`pd`.`DEPTID` = `pdou`.`DEPTORGID`))
                             union select `cs`.`ID`                   AS `id`,
                                          `cs`.`USERID`               AS `USERID`,
                                          `ou`.`EMPNAME`              AS `empname`,
                                          `cs`.`STARTTIME`            AS `STARTTIME`,
                                          `cs`.`ENDTIME`              AS `Endtime`,
                                          ifnull(`cs`.`SUMMARY`, ' ') AS `summary`,
                                          `cs`.`SUMTITLE`             AS `SUMTITLE`,
                                          'U'                         AS `DT`,
                                          `ds`.`USERID`               AS `dtid`
                                   from (((`cms`.`c_summary` `cs` join `cms`.`purview` `pv`) join `cms`.`purview_detail` `ds`) join `cms`.`om_user` `ou`)
                                   where ((`cs`.`PID` = `pv`.`ID`) and (`pv`.`ID` = `ds`.`PID`) and
                                          (`cs`.`USERID` = `ou`.`EMPID`))
                             union select `cs`.`ID`                   AS `id`,
                                          `cs`.`USERID`               AS `USERID`,
                                          `ou`.`EMPNAME`              AS `empname`,
                                          `cs`.`STARTTIME`            AS `STARTTIME`,
                                          `cs`.`ENDTIME`              AS `Endtime`,
                                          ifnull(`cs`.`SUMMARY`, ' ') AS `summary`,
                                          `cs`.`SUMTITLE`             AS `SUMTITLE`,
                                          'U'                         AS `DT`,
                                          `cs`.`USERID`               AS `dtid`
                                   from (`cms`.`c_summary` `cs` join `cms`.`om_user` `ou`)
                                   where (`cs`.`USERID` = `ou`.`EMPID`);

