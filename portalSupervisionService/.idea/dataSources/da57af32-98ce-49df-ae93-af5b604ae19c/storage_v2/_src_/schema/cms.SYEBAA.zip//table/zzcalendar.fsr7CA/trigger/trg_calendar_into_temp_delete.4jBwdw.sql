create trigger TRG_CALENDAR_INTO_TEMP_DELETE
  after DELETE
  on zzcalendar
  for each row
  BEGIN
     DELETE FROM calendar_temp WHERE id = old.id;
END;

