create view v_calendarview as
  select `c`.`id`                        AS `cid`,
         `o`.`EMPCODE`                   AS `ownerempcode`,
         `v`.`EMPCODE`                   AS `viewerempcode`,
         `c`.`begintime`                 AS `begintime`,
         `c`.`endtime`                   AS `endtime`,
         `c`.`title`                     AS `title`,
         `c`.`remark`                    AS `remark`,
         `c`.`color`                     AS `color`,
         concat(`c`.`id`, `v`.`EMPCODE`) AS `id`
  from (((`cms`.`calendarmain` `c` join `cms`.`om_user` `o` on (((`c`.`empcode` = `o`.`EMPCODE`) and (`o`.`EMPSTATUS` =
                                                                                                      '01')))) join `cms`.`sys_dict_entry_calendar` `e` on ((
    `e`.`ID` = `c`.`scope`))) join `cms`.`om_user` `v` on ((
    (`o`.`EMPCODE` <> `v`.`EMPCODE`) and (`v`.`EMPSTATUS` = '01') and
    ((`e`.`DICTNAME` = '全公司') or ((`e`.`DICTNAME` = '全部门') and (`v`.`DEPTORGID` = `c`.`deptid`)) or
     ((`e`.`DICTNAME` = '自定义') and exists(select `p`.`id`
                                          from `cms`.`calendarpermission` `p`
                                          where ((`p`.`ownerempcode` = `o`.`EMPCODE`) and
                                                 (`p`.`viewerempcode` = `v`.`EMPCODE`))))))));

