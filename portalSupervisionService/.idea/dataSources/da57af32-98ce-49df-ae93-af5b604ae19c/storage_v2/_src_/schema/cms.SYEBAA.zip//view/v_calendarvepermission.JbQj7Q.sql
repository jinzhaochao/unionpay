create view v_calendarvepermission as
  select `p`.`viewerempcode`                             AS `viewerempcode`,
         `p`.`ownerempcode`                              AS `ownerempcode`,
         `p`.`editflg`                                   AS `editflg`,
         `o`.`EMPNAME`                                   AS `ownerempname`,
         `o2`.`EMPNAME`                                  AS `viewerempname`,
         concat(`p`.`viewerempcode`, `p`.`ownerempcode`) AS `id`
  from ((`cms`.`calendarpermission` `p` join `cms`.`om_user` `o` on ((`p`.`ownerempcode` =
                                                                      `o`.`EMPCODE`))) join `cms`.`om_user` `o2` on ((
    `p`.`viewerempcode` = `o2`.`EMPCODE`)));

