create view dept_peop_view1 as select `cms`.`t_meet_people`.`USERID`  AS `empid`,
                                      `cms`.`t_meet_people`.`MEET_ID` AS `meet_id`,
                                      `cms`.`t_meet_people`.`TYPE`    AS `type`,
                                      `cms`.`t_meet_people`.`STATUS`  AS `status`,
                                      '1'                             AS `meettype`
                               from `cms`.`t_meet_people`
                               union all select `cms`.`t_meet_cc_people`.`USERID`  AS `empid`,
                                                `cms`.`t_meet_cc_people`.`MEET_ID` AS `meet_id`,
                                                `cms`.`t_meet_cc_people`.`TYPE`    AS `type`,
                                                `cms`.`t_meet_cc_people`.`STATUS`  AS `status`,
                                                '1'                                AS `meettype`
                                         from `cms`.`t_meet_cc_people`
                               union all select `cms`.`t_meet_notify_people`.`USERID`  AS `empid`,
                                                `cms`.`t_meet_notify_people`.`MEET_ID` AS `meet_id`,
                                                `cms`.`t_meet_notify_people`.`TYPE`    AS `type`,
                                                `cms`.`t_meet_notify_people`.`STATUS`  AS `status`,
                                                '1'                                    AS `meettype`
                                         from `cms`.`t_meet_notify_people`
                               union all select `org`.`EMPID`  AS `empid`,
                                                `dt`.`MEET_ID` AS `meet_id`,
                                                `dt`.`TYPE`    AS `type`,
                                                `dt`.`STATUS`  AS `status`,
                                                '2'            AS `meettype`
                                         from (`cms`.`t_meet_dept` `dt` join `cms`.`om_emporg` `org`)
                                         where (`dt`.`DEPTID` = `org`.`ORGID`)
                               union all select `org`.`EMPID`  AS `empid`,
                                                `dt`.`MEET_ID` AS `meet_id`,
                                                `dt`.`TYPE`    AS `type`,
                                                `dt`.`STATUS`  AS `status`,
                                                '2'            AS `meettype`
                                         from (`cms`.`t_meet_cc_dept` `dt` join `cms`.`om_emporg` `org`)
                                         where (`dt`.`DEPTID` = `org`.`ORGID`);

