create view userinfo_view as select `u`.`EMPID`                  AS `id`,
                                    `u`.`EMPNAME`                AS `username`,
                                    `u`.`DEGREE`                 AS `degree`,
                                    ''                           AS `ORGADDR`,
                                    `u`.`OPERTEL`                AS `trunkphone`,
                                    `u`.`BRANCH`                 AS `branch`,
                                    `u`.`OTEL`                   AS `phone`,
                                    `u`.`MOBILENO`               AS `mobile`,
                                    `u`.`FAXNO`                  AS `fax`,
                                    `u`.`PEMAIL`                 AS `outmail`,
                                    'o'                          AS `SOURCE`,
                                    (case
                                       when isnull(`u`.`JOBTITLES`) then `u`.`REMARK`
                                       else `u`.`JOBTITLES` end) AS `groupname`,
                                    `u`.`OEMAIL`                 AS `inmail`,
                                    'UNIONPAY_INNER'             AS `groupType`,
                                    `u`.`USERID`                 AS `userid`,
                                    `u`.`DEPTORGID`              AS `DEPTID`,
                                    `u`.`ORGID`                  AS `orgid`,
                                    `u`.`FAVOR`                  AS `FAVOR`,
                                    `u`.`EMPCODE`                AS `empcode`
                             from (`cms`.`om_user_addressbook` `u` join `cms`.`om_emporg` `r`)
                             where ((`u`.`EMPID` = `r`.`EMPID`) and
                                    ((`u`.`EMPSTATUS` = '01') or (`u`.`EMPSTATUS` = '02')) and
                                    ((`u`.`EMPTYPE` <> '00') or isnull(`u`.`EMPTYPE`)))
                             union select `u`.`USER_ID`     AS `id`,
                                          `u`.`NAME`        AS `username`,
                                          `u`.`DEGREE`      AS `degree`,
                                          `g`.`ADDRESS`     AS `address`,
                                          `u`.`TRUNK_PHONE` AS `trunkphone`,
                                          `u`.`BRANCH`      AS `branch`,
                                          `u`.`PHONE`       AS `phone`,
                                          `u`.`MOBILE`      AS `mobile`,
                                          `u`.`FAX`         AS `fax`,
                                          `u`.`OUT_MAIL`    AS `outmail`,
                                          'i'               AS `SOURCE`,
                                          `g`.`GROUP_NAME`  AS `groupname`,
                                          `u`.`IN_MAIL`     AS `inmail`,
                                          `g`.`GROUP_TYPE`  AS `groupType`,
                                          NULL              AS `userid`,
                                          0                 AS `DEPTID`,
                                          0                 AS `orgid`,
                                          0                 AS `favor`,
                                          0                 AS `empcode`
                                   from (`cms`.`addbook_user` `u` join `cms`.`addbook_group` `g`)
                                   where (`u`.`GROUP_ID` = `g`.`GROUP_ID`) order by `username`;

