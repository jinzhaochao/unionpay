create trigger TRG_CALENDAR_INTO_TEMP_UPDATE
  after UPDATE
  on zzcalendar
  for each row
  BEGIN
   declare  starttime_temp datetime;
     declare endtime_temp datetime;
     declare dt_starttime datetime;
     declare dt_endtime datetime;
     declare str_starthour VARCHAR(20);
     declare str_endhour VARCHAR(20);
   DELETE FROM calendar_temp WHERE id = old.id;
     set starttime_temp = str_to_date(date_format(str_to_date(new.starttime,'%Y/%m/%d %H:%i:%s'),'%Y-%m-%d'),'%Y-%m-%d');
     set endtime_temp = str_to_date(date_format(str_to_date(new.endtime,'%Y/%m/%d %H:%i:%s'),'%Y-%m-%d'),'%Y-%m-%d');
     set dt_starttime = str_to_date(date_format(str_to_date(new.starttime,'%Y/%m/%d %H:%i:%s'),'%Y-%m-%d'),'%Y-%m-%d');
     set dt_endtime = str_to_date(date_format(str_to_date(new.endtime,'%Y/%m/%d %H:%i:%s'),'%Y-%m-%d'),'%Y-%m-%d');
     set str_starthour = date_format(str_to_date(new.starttime,'%Y/%m/%d %H:%i:%s'),'%H:%i');
     set str_endhour = date_format(str_to_date(new.endtime,'%Y/%m/%d %H:%i:%s'),'%H:%i');
     WHILE(dt_starttime <= dt_endtime) do
        IF(dt_starttime = starttime_temp AND dt_endtime = endtime_temp AND dt_starttime = dt_endtime) THEN
          INSERT INTO calendar_temp(id,userid,subject,address,remark,starttime,endtime,color,isallday,isloop,pid,status,inviteid)
          VALUES(new.id,new.userid,new.subject,new.address,new.remark,concat(date_format(dt_starttime,'%Y/%m/%d') , ' ' , str_starthour),concat(date_format(dt_endtime,'%Y/%m/%d') , ' ' , str_endhour),new.color,new.isallday,new.isloop,new.pid,new.status,new.inviteid);
        ELSEIF(dt_starttime = starttime_temp) THEN
          INSERT INTO calendar_temp(id,userid,subject,address,remark,starttime,endtime,color,isallday,isloop,pid,status,inviteid)
          VALUES(new.id,new.userid,new.subject,new.address,new.remark,concat(date_format(dt_starttime,'%Y/%m/%d') , ' ' , str_starthour),concat(date_format(dt_starttime,'%Y/%m/%d') , ' 23:59'),new.color,new.isallday,new.isloop,new.pid,new.status,new.inviteid);
        ELSEIF(dt_starttime = endtime_temp) THEN
          INSERT INTO calendar_temp(id,userid,subject,address,remark,starttime,endtime,color,isallday,isloop,pid,status,inviteid)
          VALUES(new.id,new.userid,new.subject,new.address,new.remark,concat(date_format(dt_starttime,'%Y/%m/%d') , ' 00:00'),concat(date_format(dt_starttime,'%Y/%m/%d') , ' ' , str_endhour),new.color,new.isallday,new.isloop,new.pid,new.status,new.inviteid);
        ELSE
          INSERT INTO calendar_temp(id,userid,subject,address,remark,starttime,endtime,color,isallday,isloop,pid,status,inviteid)
          VALUES(new.id,new.userid,new.subject,new.address,new.remark,concat(date_format(dt_starttime,'%Y/%m/%d') , ' 00:00'),concat(date_format(dt_starttime,'%Y/%m/%d') , ' 23:59'),new.color,new.isallday,new.isloop,new.pid,new.status,new.inviteid);
        END IF;
       set dt_starttime = date_add(dt_starttime, interval 1 day);
     END while;
END;

