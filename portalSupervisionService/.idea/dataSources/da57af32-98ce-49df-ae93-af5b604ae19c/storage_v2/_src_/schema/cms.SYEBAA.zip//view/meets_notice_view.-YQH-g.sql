create view meets_notice_view as
  select distinct `tm`.`ID`                           AS `ID`,
                  `tm`.`MEET_TITLE`                   AS `MEET_TITLE`,
                  `tm`.`MEET_TYPE`                    AS `MEET_TYPE`,
                  `tm`.`MEET_BEGIN_TIME`              AS `MEET_BEGIN_TIME`,
                  `tm`.`MEET_ADDRESS`                 AS `MEET_ADDRESS`,
                  `tm`.`MEET_USERS`                   AS `MEET_USERS`,
                  `tm`.`RELEASE_USER`                 AS `RELEASE_USER`,
                  `tm`.`RELEASE_TIME`                 AS `RELEASE_TIME`,
                  `tm`.`RELEASE_UNIT`                 AS `RELEASE_UNIT`,
                  ifnull(`tm`.`RELEASE_CONTENT`, ' ') AS `release_content`,
                  ifnull(`tm`.`RELEASE_ANNEX`, ' ')   AS `release_annex`,
                  `tm`.`RELEASE_STATUS`               AS `RELEASE_STATUS`,
                  `tm`.`MEET_END_TIME`                AS `MEET_END_TIME`,
                  min(`dp`.`type`)                    AS `type`,
                  `dp`.`empid`                        AS `empid`,
                  max(ifnull(`dp`.`status`, -(1)))    AS `status`
  from (`cms`.`t_meet_release_notice` `tm` join `cms`.`dept_peop_view` `dp`)
  where ((`tm`.`ID` = `dp`.`meet_id`) and ((`dp`.`status` in (0, 1, 2, 3)) or isnull(`dp`.`status`)) and
         (`tm`.`RELEASE_STATUS` in (1, 2)))
  group by `tm`.`ID`, `tm`.`MEET_TITLE`, `tm`.`MEET_TYPE`, `tm`.`MEET_BEGIN_TIME`, `tm`.`MEET_ADDRESS`,
           `tm`.`MEET_USERS`, `tm`.`RELEASE_USER`, `tm`.`RELEASE_TIME`, `tm`.`RELEASE_UNIT`,
           ifnull(`tm`.`RELEASE_CONTENT`, ' '), ifnull(`tm`.`RELEASE_ANNEX`, ' '), `tm`.`RELEASE_STATUS`,
           `tm`.`MEET_END_TIME`, `dp`.`empid`;

