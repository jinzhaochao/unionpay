create view v_purviewdeptdetail as select distinct `u`.`EMPID`   AS `empid`,
                                                   `pd`.`PID`    AS `pid`,
                                                   `u`.`EMPNAME` AS `empname`,
                                                   `u`.`SORTNO`  AS `sortno`
                                   from (`cms`.`om_user` `u` join `cms`.`purview_detail` `pd`)
                                   where ((`u`.`EMPID` = `pd`.`USERID`) and
                                          ((`u`.`EMPSTATUS` = 1) or (`u`.`EMPSTATUS` = 2) or (`u`.`EMPSTATUS` = 4)))
                                   union all select distinct `u`.`EMPID`   AS `empid`,
                                                             `pt`.`PID`    AS `pid`,
                                                             `u`.`EMPNAME` AS `empname`,
                                                             `u`.`SORTNO`  AS `sortno`
                                             from (((`cms`.`om_user` `u` join `cms`.`purview_dept` `pt`) join `cms`.`om_organization` `g`) join `cms`.`om_emporg` `om`)
                                             where ((`pt`.`DEPTID` = `om`.`ORGID`) and (`om`.`ORGID` = `g`.`ORGID`) and
                                                    (`om`.`EMPID` = `u`.`EMPID`) and
                                                    ((`u`.`EMPSTATUS` = 1) or (`u`.`EMPSTATUS` = 2) or (`u`.`EMPSTATUS` = 4))) order by `sortno`;

